# Literacy India Bijwasan Centre - Research Findings

## Organization Overview
- **Name:** Literacy India (Bijwasan Centre)
- **Type:** Non-profit Organization (NGO)
- **Founded:** 1996 by Captain Indraani Singh
- **Mission:** To create self-sufficient communities by empowering underprivileged children, youth, and women through education, skilling, and holistic development.
- **Core Values (4Es):** Education, Employability, Empowerment, and Environment.

## Bijwasan Centre Specifics
- **Name:** Sampurna Shiksha Centre at Bijwasan.
- **Location:** Near Old Water Tank, Bijwasan, New Delhi.
- **Focus:** Exclusively dedicated to empowering girl children and women.
- **Key Programs:**
    - **Pathshala Project:** Academic support for girls in Class 6th to 10th (Maths, Science, English).
    - **Digital Literacy:** Coding (Code.org), computer training, and technology-driven learning.
    - **Vocational Training:** Skill-building for youth and women to ensure employability.
    - **Financial Literacy:** Training on banking, saving, and investing.
    - **Theatre in Education:** Integrating performing arts into learning.

## Impact & Success Stories
- **Aarti:** 16-year-old aspiring software engineer from Ambedkar Colony, Bijwasan.
- **Neha:** A story of resilience and triumph in the Bijwasan neighborhood.
- **Tannu:** Grade 10 student at Pathshala project, Bijwasan.
- **General Impact:** Literacy India has touched over 6.1 million lives across 165+ centres in 20 states.

## Contact Information
- **Centre Address:** Near Old Water Tank, Bijwasan, New Delhi.
- **Head Office Address:** J-1365, Palam Vihar, Gurugram - 122017, Haryana, India.
- **Phone:** 9811830622 / 9811820233 / 9811820027
- **Email:** info@literacyindia.org
- **Website:** https://literacyindia.org/

## Visual Identity
- **Logo:** Features "LITERACY INDIA" with the tagline "Transforming Lives, Building Resilient Communities".
- **Colors:** Orange, Green, and Blue are prominent in their branding.
